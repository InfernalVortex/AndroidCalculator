

/**
 * Created by Pranav on 12/2/2015.
 */
public interface CalculatorViewInterface {
    public void display(String val);

    public void invalid();
}
